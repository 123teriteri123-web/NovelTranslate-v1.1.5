
import os
from datetime import datetime
from flask import Flask, request, jsonify, render_template, redirect, url_for, send_file, abort
from werkzeug.utils import secure_filename

from models import db, Novel, Chapter
from content_extractor import extract_text, split_into_chapters
from chapter_processor import ChapterProcessor
from translation_service import TranslationService
from output_generator import build_markdown
from epub_generator import generate_epub

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(os.path.dirname(__file__), "instance", "translation_dashboard.db")
    os.makedirs(os.path.join(os.path.dirname(__file__), "instance"), exist_ok=True)
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    db.init_app(app)
    with app.app_context():
        db.create_all()
    return app

app = create_app()

@app.route("/")
def index():
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    novels = Novel.query.order_by(Novel.created_at.desc()).all()
    return render_template("dashboard.html", novels=novels)

@app.route("/novel/<int:novel_id>")
def view_novel(novel_id):
    novel = Novel.query.get_or_404(novel_id)
    chapters = Chapter.query.filter_by(novel_id=novel.id).order_by(Chapter.order).all()
    return render_template("novel.html", novel=novel, chapters=chapters)

@app.route("/novel/<int:novel_id>/chapter/<int:order>")
def view_chapter(novel_id, order):
    ch = Chapter.query.filter_by(novel_id=novel_id, order=order).first()
    if not ch:
        abort(404)
    return render_template("chapter.html", chapter=ch)

@app.route("/api/upload_novel", methods=["POST"])
def upload_novel():
    if "file" not in request.files:
        return jsonify({"error": "No file"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400
    filename = secure_filename(f.filename)
    path = os.path.join(UPLOAD_DIR, filename)
    f.save(path)

    title = os.path.splitext(filename)[0]
    novel = Novel(title=title, filepath=path)
    db.session.add(novel)
    db.session.commit()

    # Extract and split chapters
    try:
        raw = extract_text(path)
        pairs = split_into_chapters(raw)
        ChapterProcessor(novel).ingest_chapters(pairs)
    except Exception as e:
        return jsonify({"error": f"Failed to process chapters: {e}"}), 500

    return jsonify({"success": True, "novel_id": novel.id})

@app.route("/api/test_key", methods=["POST"])
def test_key():
    key = request.json.get("api_key", "").strip()
    if not key:
        return jsonify({"ok": False, "error": "Missing api_key"}), 400
    os.environ["OPENROUTER_API_KEY"] = key  # set for current process
    try:
        svc = TranslationService(api_key=key)
        ok = svc.test_api_connection()
        return jsonify({"ok": ok})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400

@app.route("/api/translate_chapter/<int:novel_id>/<int:order>", methods=["POST"])
def translate_chapter(novel_id, order):
    data = request.get_json(force=True, silent=True) or {}
    target_language = data.get("target_language", "English")
    source_language = data.get("source_language", "auto")

    ch = Chapter.query.filter_by(novel_id=novel_id, order=order).first_or_404()
    try:
        svc = TranslationService()  # reads env OPENROUTER_API_KEY
        translated = svc.translate(ch.source_text, source_language=source_language, target_language=target_language)
        ch.translated_text = translated
        ch.translated_at = datetime.utcnow()
        db.session.commit()
        return jsonify({"success": True, "chapter_id": ch.id})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/export_epub/<int:novel_id>", methods=["POST"])
def export_epub(novel_id):
    novel = Novel.query.get_or_404(novel_id)
    chapters = Chapter.query.filter_by(novel_id=novel.id).order_by(Chapter.order).all()
    out = generate_epub(novel.title, author="", chapters=chapters, out_dir=OUTPUT_DIR)
    rel = os.path.relpath(out, start=os.path.dirname(__file__))
    return jsonify({"success": True, "path": rel})

@app.route("/download/<path:rel>")
def download(rel):
    rel = rel.strip("/")
    path = os.path.join(os.path.dirname(__file__), rel)
    if not os.path.isfile(path):
        abort(404)
    return send_file(path, as_attachment=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

@app.route("/api/translate_all/<int:novel_id>/<lang>", methods=["POST"])
def translate_all(novel_id, lang):
    novel = Novel.query.get_or_404(novel_id)
    chapters = Chapter.query.filter_by(novel_id=novel.id).order_by(Chapter.order).all()
    svc = TranslationService()
    for ch in chapters:
        if not ch.translated_content:
            ch.translated_content = svc.translate(ch.content, target_lang=lang)
            db.session.commit()
    return jsonify({"success": True})

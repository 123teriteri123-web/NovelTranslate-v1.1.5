# Novel Translation Dashboard

## Overview

This is a Flask-based web application that provides a dashboard for translating novels using AI translation services. The system allows users to upload text files containing novels, automatically breaks them into manageable chapters, translates them using the OpenRouter API, and generates EPUB files for easy reading. The application features a simple authentication system and provides real-time progress tracking for translation jobs.

## Recent Changes (August 24, 2025)

- **Security Enhancement**: Moved API keys from database storage to secure environment variables (OPENROUTER_API_KEY, LOGIN_PASSWORD)
- **UI/UX Improvements**: Added YouTube-style toggle translation button with play/stop functionality
- **Translation Control**: Implemented translation cancellation feature - users can stop translation mid-process
- **Database Migration**: Upgraded from SQLite to PostgreSQL for better performance and reliability
- **Memory System**: Full data persistence with local storage working correctly
- **Layout Fixes**: Resolved spacing issues and UI bumps for cleaner appearance

## Current Status

- ✅ Database: PostgreSQL with full persistence (novels, batches, translations stored locally)
- ✅ Authentication: Secure environment-based login system
- ✅ Translation: OpenRouter API integration with DeepSeek R1 Lite model
- ✅ File Processing: Successfully processes novels into chapters and batches
- ✅ UI: Clean, responsive dashboard with proper spacing and controls

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Flask with Jinja2 templating
- **UI Components**: Bootstrap 5 with dark theme for responsive design
- **Client-side Logic**: Vanilla JavaScript for API interactions and real-time updates
- **Styling**: Custom CSS with Font Awesome icons for enhanced visual experience

### Backend Architecture
- **Web Framework**: Flask with SQLAlchemy ORM for database operations
- **Database Layer**: SQLite for development with configurable PostgreSQL support via environment variables
- **File Processing**: Custom chapter extraction and content processing modules
- **Translation Engine**: Integration with OpenRouter API using DeepSeek R1 Lite model
- **Content Generation**: Custom EPUB generator for creating downloadable ebook files

### Authentication System
- **Mechanism**: Simple session-based authentication with password protection
- **Security**: Session management with configurable secret keys
- **Access Control**: Route-level protection for dashboard functionality

### File Management
- **Upload Handling**: Secure file upload with size limits (16MB maximum)
- **Storage Structure**: Separate directories for uploads and generated outputs
- **Content Processing**: Automated chapter detection using multiple pattern matching strategies

### Translation Pipeline
- **Chapter Processing**: Intelligent chapter detection using regex patterns for multiple languages
- **Batch Processing**: Content divided into manageable batches for translation
- **Progress Tracking**: Real-time status updates for translation jobs
- **Content Formatting**: Preservation of original formatting and literary style

### Data Models
- **Novel Management**: Storage of uploaded files with metadata and chapter information
- **Batch System**: Granular tracking of translation progress by content sections
- **API Configuration**: Secure storage of translation service credentials

## External Dependencies

### Translation Services
- **OpenRouter API**: Primary translation service using DeepSeek R1 Lite model
- **API Authentication**: Bearer token authentication with custom headers

### Database Systems
- **Current**: PostgreSQL with full persistence and rollback support
- **Connection**: Managed via DATABASE_URL environment variable  
- **ORM**: SQLAlchemy with connection pooling and health checks
- **Data Storage**: All novels, chapters, batches, and translations stored locally

### Content Generation
- **EPUB Creation**: ebooklib library for generating standard EPUB files
- **File Processing**: Python standard libraries for text processing and file handling

### Frontend Libraries
- **Bootstrap 5**: UI framework with Replit dark theme integration
- **Font Awesome**: Icon library for enhanced user interface
- **JavaScript**: Native browser APIs for asynchronous operations

### Development Tools
- **Flask Development Server**: Built-in development server with debug mode
- **Logging**: Python logging module for debugging and monitoring
- **Proxy Support**: Werkzeug ProxyFix for deployment behind reverse proxies

### Security Considerations
- **File Upload**: Secure filename handling and file type validation
- **Session Management**: Configurable session secrets with fallback defaults
- **Input Validation**: Content sanitization and secure file processing
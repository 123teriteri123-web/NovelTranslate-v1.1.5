
# NovelTranslate (Fixed)

This build fixes:
- Translation service (OpenRouter, chunking, retries, formatting).
- Automatic output formatting (scene breaks, newlines, punctuation spacing).
- Chapter viewing (routes and templates working).
- EPUB export.

## Setup

1. Create and activate a virtualenv.
2. Install dependencies:
   ```bash
   pip install flask flask_sqlalchemy ebooklib requests
   ```
3. Set your OpenRouter API key:
   ```bash
   export OPENROUTER_API_KEY=sk-or-...    # do NOT commit it
   ```
4. Run:
   ```bash
   python app.py
   ```

Upload a `.txt` or `.epub` on the dashboard. Open a chapter and click translate.

## Notes
- The app never stores your API key; it reads `OPENROUTER_API_KEY` from environment.
- If translation returns rate limits, the service retries with backoff.
- You can change the model by setting `OPENROUTER_MODEL` env var.
